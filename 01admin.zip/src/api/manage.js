import { axios } from '@/utils/request'

const api = {
  user: '/user',
  role: '/role',
  service: '/service',
  permission: '/permission',
  permissionNoPager: '/permission/no-pager',
  orgTree: '/org/tree',
  Class: {
    list:'/class/list'
  },
  Grade: {
    list:'/grade/list'
  },
  Room: {
    list:'/room/list'
  },
  Student: {
    list:'/student/list'
  },
  Teacher: {
    list:'/teacher/list'
  },
  Famliy: {
    list:'/famliy/list'
  },
  Subject: {
    list:'/subject/list'
  },
  Schedule: {
    list:'/schedule/list'
  },
  Experiment: {
    Exam:{
      list:'/experiment/exam/list',
      Video:{
        list:'/experiment/exam/video/list'
      }
    }
  }
}

export default api

export function getUserList(parameter) {
  return axios({
    url: api.user,
    method: 'get',
    params: parameter
  })
}

export function getRoleList(parameter) {
  return axios({
    url: api.role,
    method: 'get',
    params: parameter
  })
}

export function getServiceList(parameter) {
  return axios({
    url: api.service,
    method: 'get',
    params: parameter
  })
}
// 班级接口
export function getClassList(parameter) {
  return axios({
    url: '/cls/list',
    method: 'get',
    params: parameter
  })
}

export function addClass(parameter) {
  return axios({
    url: '/cls/add',
    method: 'post',
    data: parameter
  })
}

export function getClass(parameter) {
  return axios({
    url: '/cls/info',
    method: 'get',
    params: parameter
  })
}

export function editClass(parameter) {
  return axios({
    url: '/cls/update',
    method: 'post',
    data: parameter
  })
}

export function delClass(parameter) {
  return axios({
    url: '/cls/delete',
    method: 'post',
    data: parameter
  })
}

// 教室接口
export function getRoomList(parameter) {
  return axios({
    url: '/classRoom/list',
    method: 'get',
    params: parameter
  })
}

export function addRoom(parameter) {
  return axios({
    url: '/classRoom/add',
    method: 'post',
    data: parameter
  })
}

export function getRoom(parameter) {
  return axios({
    url: '/classRoom/info',
    method: 'get',
    params: parameter
  })
}

export function editRoom(parameter) {
  return axios({
    url: '/classRoom/update',
    method: 'post',
    data: parameter
  })
}

export function delRoom(parameter) {
  return axios({
    url: '/classRoom/delete',
    method: 'post',
    data: parameter
  })
}

export function getGradeList(parameter) {
  return axios({
    url: api.Grade.list,
    method: 'get',
    params: parameter
  })
}



export function getStudentList(parameter) {
  return axios({
    url: api.Student.list,
    method: 'get',
    params: parameter
  })
}
export function getTeacherList(parameter) {
  return axios({
    url: api.Teacher.list,
    method: 'get',
    params: parameter
  })
}
export function getFamliyList(parameter) {
  return axios({
    url: api.Famliy.list,
    method: 'get',
    params: parameter
  })
}

export function getSubjectList(parameter) {
  return axios({
    url: api.Subject.list,
    method: 'get',
    params: parameter
  })
}

export function getScheduleList(parameter) {
  return axios({
    url: api.Schedule.list,
    method: 'get',
    params: parameter
  })
}

export function getExperimentExamVideoList(parameter) {
  return axios({
    url: api.Experiment.Exam.Video.list,
    method: 'get',
    params: parameter
  })
}

export function getExperimentExamList(parameter) {
  return axios({
    url: api.Experiment.Exam.list,
    method: 'get',
    params: parameter
  })
}


export function getPermissions(parameter) {
  return axios({
    url: api.permissionNoPager,
    method: 'get',
    params: parameter
  })
}

export function getOrgTree(parameter) {
  return axios({
    url: api.orgTree,
    method: 'get',
    params: parameter
  })
}

// id == 0 add     post
// id != 0 update  put
export function saveService(parameter) {
  return axios({
    url: api.service,
    method: parameter.id == 0 ? 'post' : 'put',
    data: parameter
  })
}