<template>
  <div class="card-list" ref="content">
    <a-list
            :grid="{gutter: 24, lg: 3, md: 2, sm: 1, xs: 1}"
            :dataSource="dataSource"
    >
      <a-list-item slot="renderItem" slot-scope="item, index">
        <template v-if="item === null">
          <a-button class="new-btn" type="dashed">
            <a-icon type="plus"/>
            新增产品
          </a-button>
        </template>
        <template v-else>
          <a-card :hoverable="true">
            <a-card-meta>
              <div style="margin-bottom: 3px" slot="title">{{ item.title }}</div>
              <a-avatar class="card-avatar" slot="avatar" :src="item.avatar" size="large"/>
              <div class="meta-content" slot="description">{{ item.content }}</div>
            </a-card-meta>
            <template class="ant-card-actions" slot="actions">
              <a>管理</a>
              <a>预览</a>
            </template>
          </a-card>
        </template>
      </a-list-item>
    </a-list>
  </div>
</template>

<script>

  const dataSource = []
  dataSource.push(null)
    dataSource.push({
      title: '课题互动',
      avatar: 'https://gw.alipayobjects.com/zos/rmsportal/WdGqmHpayyMjxxxiEhcKoVE.png',
      content: '智慧教育生态最贴近课堂的一环,实现了教学与科技的完美结合'
    })
    dataSource.push({
      title: '数字班牌',
      avatar: 'https://gw.alipayobjects.com/zos/rmsportal/WdGqmHpayyMjxxxiEhcKoVE.png',
      content: '班级的窗口,便捷的实现了学生考勤,老师到课,风采展示,安保监控等多位一体的智慧终端'
    })
    dataSource.push({
      title: '实验考试系统',
      avatar: 'https://gw.alipayobjects.com/zos/rmsportal/WdGqmHpayyMjxxxiEhcKoVE.png',
      content: '实时录制实验考试过程,方便老师多角度,多时间节点动态点评'
    })
    dataSource.push({
      title: '云课件',
      avatar: 'https://gw.alipayobjects.com/zos/rmsportal/WdGqmHpayyMjxxxiEhcKoVE.png',
      content: '海量权威数据,一键分享到课堂'
    })


  export default {
    name: 'CardList',
    data () {
      return {
        description: '段落示意：蚂蚁金服务设计平台 ant.design，用最小的工作量，无缝接入蚂蚁金服生态， 提供跨越设计与开发的体验解决方案。',
        linkList: [
          { icon: 'rocket', href: '#', title: '快速开始' },
          { icon: 'info-circle-o', href: '#', title: '产品简介' },
          { icon: 'file-text', href: '#', title: '产品文档' }
        ],
        extraImage: 'https://gw.alipayobjects.com/zos/rmsportal/RzwpdLnhmvDJToTdfDPe.png',
        dataSource
      }
    }
  }
</script>

<style lang="less" scoped>
  .card-avatar {
    width: 48px;
    height: 48px;
    border-radius: 48px;
  }

  .ant-card-actions {
    background: #f7f9fa;
  li {
    float: left;
    text-align: center;
    margin: 12px 0;
    color: rgba(0, 0, 0, 0.45);
    width: 50%;

  &:not(:last-child) {
     border-right: 1px solid #e8e8e8;
   }

  a {
    color: rgba(0, 0, 0, .45);
    line-height: 22px;
    display: inline-block;
    width: 100%;
  &:hover {
     color: #1890ff;
   }
  }
  }
  }

  .new-btn {
    background-color: #fff;
    border-radius: 2px;
    width: 100%;
    height: 188px;
  }

  .meta-content {
    position: relative;
    overflow: hidden;
    text-overflow: ellipsis;
    display: -webkit-box;
    height: 64px;
    -webkit-line-clamp: 3;
    -webkit-box-orient: vertical;
  }
</style>