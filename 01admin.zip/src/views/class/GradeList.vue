<template>
  <a-card :bordered="false">

    <div class="table-operator">
      <a-button type="primary" icon="setting" @click="handleSetting" >设置</a-button>
    </div>

    <s-table
      ref="table"
      size="default"
      :columns="columns"
      :data="loadData"
      :alert="{ show: true, clear: () => { this.selectedRowKeys = [] } }"
      :rowSelection="{ selectedRowKeys: selectedRowKeys, onChange: onSelectChange }"
    >

    </s-table>

    <a-modal
      title="设置"
      :width="800"
      v-model="visible"
      @ok="handleOk"
    >
      <a-form :autoFormCreate="(form)=>{this.form = form}">

        <a-form-item
          :labelCol="labelCol"
          :wrapperCol="wrapperCol"
          label="开学日期"
          hasFeedback
          validateStatus="success"
          help="系统根据此日期自动更新年级数据"
        >
          <a-date-picker :format="'MM/DD'" />
        </a-form-item>

      </a-form>
    </a-modal>

  </a-card>
</template>

<script>
  import STable from '@/components/table/'
  import ATextarea from 'ant-design-vue/es/input/TextArea'
  import AInput from 'ant-design-vue/es/input/Input'
  import moment from 'moment'

  import { getRoleList, getGradeList } from '@/api/manage'

  export default {
    name: 'GradeList',
    components: {
      AInput,
      ATextarea,
      STable
    },
    data () {
      return {
        visible: false,
//        description: '全校班级管理。',
        labelCol: {
          xs: { span: 24 },
          sm: { span: 5 },
        },
        wrapperCol: {
          xs: { span: 24 },
          sm: { span: 12 },
        },
        form: null,
        mdl: {},

        // 高级搜索 展开/关闭
        advanced: false,
        // 查询参数
        queryParam: {},
        // 表头
        columns: [
          {
            title: '编号',
            dataIndex: 'no',
          },
          {
            title: '年级',
            dataIndex: 'name'
          },
          {
            title: '入学年级',
            dataIndex: 'year',
            sorter: true,
            customRender: (text) => text + ' 年'
          },
          {
            title: '班级数',
            dataIndex: 'member_count',
            needTotal: true,
            sorter: true
          },
          {
            title: '人数',
            dataIndex: 'class_count',
            needTotal: true,
            sorter: true
          },
          {
            title: '状态',
            dataIndex: 'status',
            customRender: (text) =>  {
              switch (text){
                case 1 : return '正常';
                case 2 : return '未开学';
                case 3 : return '已毕业';
              }
            }
          },
          {
            table: '操作',
            dataIndex: 'action',
            width: '150px',
            scopedSlots: { customRender: 'action' },
          }
        ],
        // 加载数据方法 必须为 Promise 对象
        loadData: parameter => {
          return getGradeList(Object.assign(parameter, this.queryParam))
            .then(res => {
              return res.result
            })
        },

        selectedRowKeys: [],
        selectedRows: []
      }
    },
    created () {
      getRoleList({ t: new Date()})
    },
    methods: {
      handleSetting () {
        this.visible = true
      },
      handleOk () {

      },

      onSelectChange (selectedRowKeys, selectedRows) {
        this.selectedRowKeys = selectedRowKeys
        this.selectedRows = selectedRows
      },
      toggleAdvanced () {
        this.advanced = !this.advanced
      },

      resetSearchForm () {
        this.queryParam = {
          date: moment(new Date())
        }
      }
    },
    watch: {
      /*
      'selectedRows': function (selectedRows) {
        this.needTotalList = this.needTotalList.map(item => {
          return {
            ...item,
            total: selectedRows.reduce( (sum, val) => {
              return sum + val[item.dataIndex]
            }, 0)
          }
        })
      }
      */
    }
  }
</script>