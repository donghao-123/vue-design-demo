<template>
  <a-card :bordered="false">
    <div class="table-page-search-wrapper">
      <a-form layout="inline">
        <a-row :gutter="48">
          <a-col :md="8" :sm="24">
            <a-form-item label="关键字">
              <a-input v-model="queryParam.keyword" placeholder=""/>
            </a-form-item>
          </a-col>
          <a-col :md="8" :sm="24">
            <a-form-item label="入学年份">
              <a-select v-model="queryParam.year" placeholder="请选择" allowClear default-value="0">
                <a-select-option value="2015">2015</a-select-option>
            <a-select-option value="2016">2016</a-select-option>
            <a-select-option value="2017">2017</a-select-option>
            <a-select-option value="2018">2018</a-select-option>
            <a-select-option value="2019">2019</a-select-option>
            <a-select-option value="2020">2020</a-select-option>
              </a-select>
            </a-form-item>
          </a-col>
          <template v-if="advanced">
            <a-col :md="8" :sm="24">
              <a-form-item label="调用次数">
                <a-input-number v-model="queryParam.callNo" style="width: 100%"/>
              </a-form-item>
            </a-col>
            <a-col :md="8" :sm="24">
              <a-form-item label="更新日期">
                <a-date-picker v-model="queryParam.date" style="width: 100%" placeholder="请输入更新日期"/>
              </a-form-item>
            </a-col>
            <a-col :md="8" :sm="24">
              <a-form-item label="使用状态">
                <a-select v-model="queryParam.useStatus" placeholder="请选择" default-value="0">
                  <a-select-option value="0">全部</a-select-option>
                  <a-select-option value="1">关闭</a-select-option>
                  <a-select-option value="2">运行中</a-select-option>
                </a-select>
              </a-form-item>
            </a-col>
            <a-col :md="8" :sm="24">
              <a-form-item label="使用状态">
                <a-select placeholder="请选择" default-value="0">
                  <a-select-option value="0">全部</a-select-option>
                  <a-select-option value="1">关闭</a-select-option>
                  <a-select-option value="2">运行中</a-select-option>
                </a-select>
              </a-form-item>
            </a-col>
          </template>
          <a-col :md="!advanced && 8 || 24" :sm="24">
            <span class="table-page-search-submitButtons" :style="advanced && { float: 'right', overflow: 'hidden' } || {} ">
              <a-button type="primary" @click="$refs.table.refresh(true)">查询</a-button>
              <a-button style="margin-left: 8px" @click="() => queryParam = {}">重置</a-button>
              <a @click="toggleAdvanced" style="margin-left: 8px" v-if="false">
                {{ advanced ? '收起' : '展开' }}
                <a-icon :type="advanced ? 'up' : 'down'"/>
              </a>
            </span>
          </a-col>
        </a-row>
      </a-form>
    </div>

    <div class="table-operator">
      <a-button type="primary" icon="plus" @click="handleAdd" >新建</a-button>
      <a-dropdown v-if="selectedRowKeys.length > 0">
        <a-menu slot="overlay">
          <a-menu-item key="1"><a-icon type="delete" />删除</a-menu-item>
          <!-- lock | unlock -->
          <a-menu-item key="2"><a-icon type="lock" />锁定</a-menu-item>
        </a-menu>
        <a-button style="margin-left: 8px">
          批量操作 <a-icon type="down" />
        </a-button>
      </a-dropdown>
    </div>

    <s-table
      ref="table"
      size="default"
      :columns="columns"
      :data="loadData"
      :alert="{ show: true, clear: () => { this.selectedRowKeys = [] } }"
      :rowSelection="{ selectedRowKeys: selectedRowKeys, onChange: onSelectChange }"
    >
      <span slot="action" slot-scope="text, record">
        <template >
          <a @click="handleEdit(record)">编辑</a>
          <a-divider type="vertical" />
        </template>
        <a-dropdown>
          <a class="ant-dropdown-link">
            更多 <a-icon type="down" />
          </a>
          <a-menu slot="overlay">
            <a-menu-item>
              <a href="javascript:;">详情</a>
            </a-menu-item>
            <a-menu-item>
              <a href="javascript:;">班牌设置</a>
            </a-menu-item>
            <a-menu-item>
              <a href="javascript:;">老师设置</a>
            </a-menu-item>
            <a-menu-item>
              <a href="javascript:;">学生设置</a>
            </a-menu-item>
            <a-menu-item>
              <a href="javascript:;">教室设置</a>
            </a-menu-item>
            <a-menu-item>
              <a href="javascript:;">课程表</a>
            </a-menu-item>
            <a-menu-item>
              <a href="javascript:;">禁用</a>
            </a-menu-item>
            <a-menu-item>
               <a-popconfirm title="Are you sure delete this task?" @confirm="delConfirm(record)"  okText="Yes" cancelText="No">
    <a href="javascript:;">删除</a>
  </a-popconfirm>
            </a-menu-item>
          </a-menu>
        </a-dropdown>
      </span>
    </s-table>

    <a-modal
      title="操作"
      :width="800"
      v-model="visible"
      @ok="handleOk"
    >
      <a-form :form="form">
         <a-form-item
           v-show="false"  
        >
          <a-input  style="width: 100%" v-decorator="[
          'id',
          {rules: [ ]}
        ]" />
        </a-form-item>
   
        <a-form-item
          :labelCol="labelCol"
          :wrapperCol="wrapperCol"
          label="班级名称"
          hasFeedback
        >
 <a-input style="width: 100%" v-decorator="[
          'name',
          {rules: [{ required: true, message: '请输入班级名称' }]}
        ]"
        placeholder="请输入班级名称"/>        
        </a-form-item>

        <a-form-item
          :labelCol="labelCol"
          :wrapperCol="wrapperCol"
          label="入学年级"
        >
          <a-select  v-decorator="[
              'year',
              {rules: [{ required: true, message: '请输入入学年级' }]}
              ]"
               placeholder="2019">
            <a-select-option value="2015">2015</a-select-option>
            <a-select-option value="2016">2016</a-select-option>
            <a-select-option value="2017">2017</a-select-option>
            <a-select-option value="2018">2018</a-select-option>
            <a-select-option value="2019">2019</a-select-option>
            <a-select-option value="2020">2020</a-select-option>
          </a-select>
        </a-form-item>

          <a-form-item
          :labelCol="labelCol"
          :wrapperCol="wrapperCol"
          label="班级人数"
          hasFeedback
        >
 <a-input style="width: 100%" v-decorator="[
          'studentCount',
          {rules: [{ required: true, message: '请输入班级人数' }]}
        ]"
        placeholder="请输入班级人数"/>        
        </a-form-item>

         <a-form-item
          :labelCol="labelCol"
          :wrapperCol="wrapperCol"
          label="学校等级"
        >
          <a-select  
              v-decorator="[
              'type',
              {rules: [{ required: true, message: '请输入学校等级' }]}
              ]"
               placeholder="请输入学校等级"
          >
            <a-select-option :value="0">小学</a-select-option>
            <a-select-option :value="1">初中</a-select-option>
             <a-select-option :value="2">高中</a-select-option>
          </a-select>
        </a-form-item>

        <!-- <a-form-item
          :labelCol="labelCol"
          :wrapperCol="wrapperCol"
          label="宣言"
          hasFeedback
          help="请填写一段宣言"
        >
          <a-textarea :rows="5"/>
        </a-form-item> -->


      </a-form>
    </a-modal>

  </a-card>
</template>

<script>
import STable from '@/components/table/'
import ATextarea from 'ant-design-vue/es/input/TextArea'
import AInput from 'ant-design-vue/es/input/Input'
import moment from 'moment'

import { getRoleList, getClassList, editClass, addClass, getClass, delClass } from '@/api/manage'

export default {
  name: 'ClassList',
  components: {
    AInput,
    ATextarea,
    STable
  },
  data() {
    return {
      visible: false,
      //        description: '全校班级管理。',
      labelCol: {
        xs: { span: 24 },
        sm: { span: 5 }
      },
      wrapperCol: {
        xs: { span: 24 },
        sm: { span: 12 }
      },
      form: this.$form.createForm(this),
      mdl: {},

      // 高级搜索 展开/关闭
      advanced: false,
      // 查询参数
      queryParam: {},
      // 表头
      columns: [
        {
          title: '班级编号',
          dataIndex: 'no'
        },
        {
          title: '班级名称',
          dataIndex: 'name'
        },
        {
          title: '宣言',
          dataIndex: 'sign'
        },
        {
          title: '入学年份',
          dataIndex: 'year',
          sorter: (a, b) => a.year - b.year,
          customRender: text => text + ' 年'
        },
        {
          title: '人数',
          dataIndex: 'studentCount',
          needTotal: true,
          sorter: (a, b) => a.studentCount - b.studentCount
        },
        {
          title: '状态',
          dataIndex: 'type',
          customRender: text => {
            switch (text) {
              case 0:
                return '正常'
              case 1:
                return '已毕业'
              case 2:
                return '已锁定'
            }
          },
          filters: [
            {
              text: '正常',
              value: '0'
            },
            {
              text: '已毕业',
              value: '1'
            },
            {
              text: '已锁定',
              value: '2'
            }
          ],
          filterMultiple: false
        },
        {
          table: '操作',
          dataIndex: 'action',
          width: '150px',
          scopedSlots: { customRender: 'action' }
        }
      ],
      // 加载数据方法 必须为 Promise 对象
      loadData: parameter => {
        return getClassList(Object.assign(parameter, this.queryParam)).then(res => {
          return res.result
        })
      },

      selectedRowKeys: [],
      selectedRows: []
    }
  },
  created() {
    getRoleList({ t: new Date() })
  },
  methods: {
    // 增
    handleAdd() {
      this.visible = true
      this.form.resetFields()
    },
    // 改
    handleEdit(record) {
      let self = this
      getClass({ id: record.id }).then(res => {
        self.form.setFieldsValue({ ...res.result })
      })
      this.visible = true
    },
    // 增改 处理
    handleOk(e) {
      e.preventDefault()
      this.form.validateFields((err, values) => {
        if (!err) {
          console.log('Received values of form: ', values)
          if (values.id) {
            let self = this
            editClass(values).then(res => {
              self.$message.success('修改成功')
              self.$refs.table.refresh(true)
              self.visible = false
            })
          } else {
            let self = this
            addClass(values).then(res => {
              self.$message.success('添加成功')
              self.$refs.table.refresh(true)
              self.visible = false
            })
          }
        }
      })
    },
    // 删
    delConfirm(record) {
      console.log(record)
      let self = this
      delClass({ ids: record.id }).then(res => {
        console.log(res)
        self.$message.success('删除成功')
        self.$refs.table.refresh(true)
      })
    },
    // 查
    onSearch() {
      let self = this
      getClassList(this.queryParam).then(res => {
        self.$refs.table.refresh(true)
      })
    },

    onSelectChange(selectedRowKeys, selectedRows) {
      this.selectedRowKeys = selectedRowKeys
      this.selectedRows = selectedRows
    },
    toggleAdvanced() {
      this.advanced = !this.advanced
    },

    resetSearchForm() {
      this.queryParam = {
        date: moment(new Date())
      }
    }
  },
  watch: {
    /*
      'selectedRows': function (selectedRows) {
        this.needTotalList = this.needTotalList.map(item => {
          return {
            ...item,
            total: selectedRows.reduce( (sum, val) => {
              return sum + val[item.dataIndex]
            }, 0)
          }
        })
      }
      */
  }
}
</script>