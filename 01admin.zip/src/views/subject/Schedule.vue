<template>
  <a-card :bordered="false">
    <div class="table-page-search-wrapper">
      <a-form layout="inline">
        <a-row :gutter="48">
          <a-col :md="8" :sm="24">
            <a-form-item label="选择日期">
              <a-week-picker     placeholder="Select week" />
            </a-form-item>
          </a-col>
          <a-col :md="8" :sm="24">
            <a-form-item label="楼号" v-if="false">
              <a-select v-model="queryParam.status" placeholder="请选择" allowClear default-value="0">
                <a-select-option value="1">文德楼</a-select-option>
                <a-select-option value="2">文渊路</a-select-option>
                <a-select-option value="3">世纪楼</a-select-option>
              </a-select>
            </a-form-item>
          </a-col>
          <template v-if="advanced">
            <a-col :md="8" :sm="24">
              <a-form-item label="调用次数">
                <a-input-number v-model="queryParam.callNo" style="width: 100%"/>
              </a-form-item>
            </a-col>
            <a-col :md="8" :sm="24">
              <a-form-item label="更新日期">
                <a-date-picker v-model="queryParam.date" style="width: 100%" placeholder="请输入更新日期"/>
              </a-form-item>
            </a-col>
            <a-col :md="8" :sm="24">
              <a-form-item label="使用状态">
                <a-select v-model="queryParam.useStatus" placeholder="请选择" default-value="0">
                  <a-select-option value="0">全部</a-select-option>
                  <a-select-option value="1">关闭</a-select-option>
                  <a-select-option value="2">运行中</a-select-option>
                </a-select>
              </a-form-item>
            </a-col>
            <a-col :md="8" :sm="24">
              <a-form-item label="使用状态">
                <a-select placeholder="请选择" default-value="0">
                  <a-select-option value="0">全部</a-select-option>
                  <a-select-option value="1">关闭</a-select-option>
                  <a-select-option value="2">运行中</a-select-option>
                </a-select>
              </a-form-item>
            </a-col>
          </template>
          <a-col :md="!advanced && 8 || 24" :sm="24">
            <span class="table-page-search-submitButtons" :style="advanced && { float: 'right', overflow: 'hidden' } || {} ">
              <a-button type="primary" @click="$refs.table.refresh(true)">查询</a-button>
              <a-button style="margin-left: 8px" @click="() => queryParam = {}">重置</a-button>
              <a @click="toggleAdvanced" style="margin-left: 8px" v-if="false">
                {{ advanced ? '收起' : '展开' }}
                <a-icon :type="advanced ? 'up' : 'down'"/>
              </a>
            </span>
          </a-col>
        </a-row>
      </a-form>
    </div>

    <div class="table-operator">
      <!--<a-button type="primary" icon="plus" @click="handleAdd" >新建</a-button>-->
      <a-dropdown v-if="  selectedRowKeys.length > 0">
        <a-menu slot="overlay">
          <a-menu-item key="1"><a-icon type="delete" />删除</a-menu-item>
          <!-- lock | unlock -->
          <a-menu-item key="2"><a-icon type="lock" />锁定</a-menu-item>
        </a-menu>
        <a-button style="margin-left: 8px">
          批量操作 <a-icon type="down" />
        </a-button>
      </a-dropdown>
    </div>

    <s-table
      ref="table"
      :pagination="{postion:false}"
      :columns="columns"
      :data="loadData"
    >
      <span slot="schedule" slot-scope="schedule">
        <div v-if="schedule.subject">
          <a-tag color="blue">{{schedule.subject}}</a-tag>
          <br/>
          {{schedule.class}}
          <br/>
          {{schedule.room}}
        </div>
      </span>
      <span slot="action" slot-scope="text, record">
        <template >
          <a @click="handleEdit(record)">编辑</a>
          <a-divider type="vertical" />
        </template>
        <a-dropdown>
          <a class="ant-dropdown-link">
            更多 <a-icon type="down" />
          </a>
          <a-menu slot="overlay">
            <a-menu-item>
              <a href="javascript:;">详情</a>
            </a-menu-item>
            <a-menu-item v-if="$auth('table')">
              <a href="javascript:;">禁用</a>
            </a-menu-item>
            <a-menu-item v-if="$auth('table.delete')">
              <a href="javascript:;">删除</a>
            </a-menu-item>
          </a-menu>
        </a-dropdown>
      </span>
    </s-table>


  </a-card>
</template>

<script>
  import STable from '@/components/table/'
  import ATextarea from 'ant-design-vue/es/input/TextArea'
  import AInput from 'ant-design-vue/es/input/Input'
  import moment from 'moment'
  import 'moment/locale/zh-cn';
  moment.locale('zh-cn');

  import { getRoleList, getScheduleList } from '@/api/manage'

  export default {
    name: 'Schedule',
    components: {
      AInput,
      ATextarea,
      STable
    },
    data () {
      return {
        visible: false,
//        description: '全校班级管理。',
        labelCol: {
          xs: { span: 24 },
          sm: { span: 5 },
        },
        wrapperCol: {
          xs: { span: 24 },
          sm: { span: 12 },
        },
        form: null,
        mdl: {},

        // 高级搜索 展开/关闭
        advanced: false,
        // 查询参数
        queryParam: {},
        // 表头
        columns: [
          {
            title: '周一',
            dataIndex: 'day1',
            scopedSlots: { customRender: 'schedule' },
          },
          {
            title: '周二',
            dataIndex: 'day2',
            scopedSlots: { customRender: 'schedule' },
          },
          {
            title: '周三',
            dataIndex: 'day3',
            scopedSlots: { customRender: 'schedule' },
          },
          {
            title: '周四',
            dataIndex: 'day4',
            scopedSlots: { customRender: 'schedule' },
          },
          {
            title: '周五',
            dataIndex: 'day5',
            scopedSlots: { customRender: 'schedule' },
          },
          {
            title: '周六',
            dataIndex: 'day6',
            scopedSlots: { customRender: 'schedule' },
          },
          {
            title: '周日',
            dataIndex: 'day7',
            scopedSlots: { customRender: 'schedule' },
          },
        ],
        // 加载数据方法 必须为 Promise 对象
        loadData: parameter => {
          return getScheduleList(Object.assign(parameter, this.queryParam))
            .then(res => {
              return res.result
            })
        },

        selectedRowKeys: [],
        selectedRows: []
      }
    },
    created () {
      moment.locale('zh-cn');
      getRoleList({ t: new Date()})
    },
    methods: {
      handleAdd () {
        this.visible = true
      },
      handleEdit (record) {
        this.mdl = {...record};
        console.log(this.mdl);
        this.visible = true
      },
      handleOk () {

      },

      onSelectChange (selectedRowKeys, selectedRows) {
        this.selectedRowKeys = selectedRowKeys
        this.selectedRows = selectedRows
      },
      toggleAdvanced () {
        this.advanced = !this.advanced
      },

      resetSearchForm () {
        this.queryParam = {
          date: moment(new Date())
        }
      }
    },
    watch: {
      /*
      'selectedRows': function (selectedRows) {
        this.needTotalList = this.needTotalList.map(item => {
          return {
            ...item,
            total: selectedRows.reduce( (sum, val) => {
              return sum + val[item.dataIndex]
            }, 0)
          }
        })
      }
      */
    }
  }
</script>