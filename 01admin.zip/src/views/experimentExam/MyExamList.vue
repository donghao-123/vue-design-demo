<template>
  <a-card :bordered="false">
    <div class="table-page-search-wrapper">
      <a-form layout="inline">
        <a-row :gutter="48">
          <a-col :md="8" :sm="24">
            <a-form-item label="关键字">
              <a-input v-model="queryParam.id" placeholder=""/>
            </a-form-item>
          </a-col>
          <a-col :md="8" :sm="24">
            <a-form-item label="班级">
              <a-select v-model="queryParam.status" placeholder="请选择" allowClear default-value="0">
                <a-select-option value="1">三年(5)班</a-select-option>
                <a-select-option value="2">三年(4)班</a-select-option>
                <a-select-option value="3">三年(3)班</a-select-option>
              </a-select>
            </a-form-item>
          </a-col>

          <template v-if="advanced">
            <a-col :md="8" :sm="24">
              <a-form-item label="调用次数">
                <a-input-number v-model="queryParam.callNo" style="width: 100%"/>
              </a-form-item>
            </a-col>
            <a-col :md="8" :sm="24">
              <a-form-item label="更新日期">
                <a-date-picker v-model="queryParam.date" style="width: 100%" placeholder="请输入更新日期"/>
              </a-form-item>
            </a-col>
            <a-col :md="8" :sm="24">
              <a-form-item label="使用状态">
                <a-select v-model="queryParam.useStatus" placeholder="请选择" default-value="0">
                  <a-select-option value="0">全部</a-select-option>
                  <a-select-option value="1">关闭</a-select-option>
                  <a-select-option value="2">运行中</a-select-option>
                </a-select>
              </a-form-item>
            </a-col>
            <a-col :md="8" :sm="24">
              <a-form-item label="使用状态">
                <a-select placeholder="请选择" default-value="0">
                  <a-select-option value="0">全部</a-select-option>
                  <a-select-option value="1">关闭</a-select-option>
                  <a-select-option value="2">运行中</a-select-option>
                </a-select>
              </a-form-item>
            </a-col>
          </template>
          <a-col :md="!advanced && 8 || 24" :sm="24">
            <span class="table-page-search-submitButtons" :style="advanced && { float: 'right', overflow: 'hidden' } || {} ">
              <a-button type="primary" @click="$refs.table.refresh(true)">查询</a-button>
              <a-button style="margin-left: 8px" @click="() => queryParam = {}">重置</a-button>
              <a @click="toggleAdvanced" style="margin-left: 8px" v-if="false">
                {{ advanced ? '收起' : '展开' }}
                <a-icon :type="advanced ? 'up' : 'down'"/>
              </a>
            </span>
          </a-col>
        </a-row>
      </a-form>
    </div>

    <div class="table-operator">
      <!--<a-button type="primary" icon="plus" @click="handleAdd" >新建</a-button>-->
      <a-dropdown v-if="  selectedRowKeys.length > 0">
        <a-menu slot="overlay">
          <a-menu-item key="1"><a-icon type="delete" />删除</a-menu-item>
          <!-- lock | unlock -->
          <a-menu-item key="2"><a-icon type="lock" />锁定</a-menu-item>
        </a-menu>
        <a-button style="margin-left: 8px">
          批量操作 <a-icon type="down" />
        </a-button>
      </a-dropdown>
    </div>

    <s-table
            ref="table"
            size="default"
            :columns="columns"
            :data="loadData"
            :alert="{ show: true, clear: () => { this.selectedRowKeys = [] } }"
            :rowSelection="{ selectedRowKeys: selectedRowKeys, onChange: onSelectChange }"
    >

      <span slot="action" slot-scope="text, record">
        <template >
          <a v-if="record.status==3" @click="resultsVisible=true">查看成绩</a>
          <a v-if="record.status==2" @click="handleEdit(record)">开始考试</a>
          <a v-if="record.status==1">-</a>
          <a-divider type="vertical" />
        </template>
        <a-dropdown>
          <a class="ant-dropdown-link">
            更多 <a-icon type="down" />
          </a>
          <a-menu slot="overlay">
            <a-menu-item>
              <a href="javascript:;">示范视频</a>
            </a-menu-item>
          </a-menu>
        </a-dropdown>
      </span>
    </s-table>

    <a-modal
            title="操作"
            :width="900"
            v-model="visible"
            @ok="handleOk"
    >
      <div style="background: #ccc; width: 800px; height: 300px;line-height: 300px; text-align: center">摄像头预览</div>
      <a-card style="text-align: center">
        <a-button type="primary" icon="play-circle" v-if="playing==false" @click="start()" size="large">开始录制</a-button>
        <p v-if="playing==true" style="text-align: center; font-size: 40px; color:#000;"><count-down :target="new Date().getTime() + lastSecond*1000"  /></p>
        <p v-if="playing==true" style="text-align: center; font-size: 18px; color:#999;">到时自动提交</p>
        <a-button type="primary" icon="play-circle" v-if="playing==true" @click="reStart()" size="large">重新开始</a-button>

      </a-card>

    </a-modal>

    <a-modal
            title="成绩"
            :width="900"
            v-model="resultsVisible"
            @ok="handleOk"
    >
      <a-tabs defaultActiveKey="1"  >
        <a-tab-pane tab="过程" key="1">
          <video width="800" src="https://media.html5media.info/video.mp4" controls="controls">
            your browser does not support the video tag
          </video>


          <a-card title="过程评价">
            <a-timeline>
              <a-timeline-item>0:10 准备仪器缺失</a-timeline-item>
              <a-timeline-item>0:31 操作不规范</a-timeline-item>
              <a-timeline-item>1:32 没有达到预期结果</a-timeline-item>
            </a-timeline>
          </a-card>
        </a-tab-pane>
        <a-tab-pane tab="评分" key="2" forceRender>
          <a-form :autoFormCreate="(form)=>{this.form = form}">
            <a-form-item
                    :labelCol="labelCol"
                    :wrapperCol="wrapperCol"
                    label="操作"
                    hasFeedback
            ><a-rate :defaultValue="3" disabled /></a-form-item>
            <a-form-item
                    :labelCol="labelCol"
                    :wrapperCol="wrapperCol"
                    label="过程"
                    hasFeedback
            ><a-rate :defaultValue="3" disabled  /></a-form-item>

            <a-form-item
                    :labelCol="labelCol"
                    :wrapperCol="wrapperCol"
                    label="结果"
                    hasFeedback
            ><a-rate :defaultValue="4" disabled  /></a-form-item>

            <a-form-item
                    :labelCol="labelCol"
                    :wrapperCol="wrapperCol"
                    label="分数"
                    hasFeedback
                    help="请输入分数满分100分"
            >
              <a-input placeholder="" :defaultValue="98" disabled   />
            </a-form-item>
            <a-form-item
                    :labelCol="labelCol"
                    :wrapperCol="wrapperCol"
                    disabled
                    label="评语"
                    hasFeedback
            >
              <a-textarea :rows="5" readonly
                          :defaultValue="'不错'" />
            </a-form-item>
          </a-form>
        </a-tab-pane>
      </a-tabs>
    </a-modal>

  </a-card>
</template>

<script>
  import STable from '@/components/table/'
  import ATextarea from 'ant-design-vue/es/input/TextArea'
  import AInput from 'ant-design-vue/es/input/Input'
  import moment from 'moment'

  import { getRoleList, getExperimentExamList } from '@/api/manage'
  import CountDown from '@/components/CountDown/CountDown'
  var t = {};
  export default {
    name: 'ExperimentExamList',
    components: {
      AInput,
      ATextarea,
      STable,
      CountDown
    },
    data () {
      return {
        resultsVisible: false,
        visible: false,
        playing:false,
        lastSecond:300,
//        description: '全校班级管理。',
        labelCol: {
          xs: { span: 24 },
          sm: { span: 5 },
        },
        wrapperCol: {
          xs: { span: 24 },
          sm: { span: 12 },
        },
        form: null,
        mdl: {},

        // 高级搜索 展开/关闭
        advanced: false,
        // 查询参数
        queryParam: {},
        // 表头
        columns: [
          {
            title: 'ID',
            dataIndex: 'id',
          },
          {
            title: '考试日期',
            dataIndex: 'date_time'
          },
          {
            title: '学科',
            dataIndex: 'subject',
          },
          {
            title: '名称',
            dataIndex: 'name',
          },
          {
            title: '状态',
            dataIndex: 'status',
            customRender: (text) =>  {
              switch (text){
                case 1 : return '未开始';
                case 2 : return '进行中';
                case 3 : return '已结束';
              }
            }
          },
          {
            table: '操作',
            dataIndex: 'action',
            width: '200px',
            scopedSlots: { customRender: 'action' },
          }
        ],
        // 加载数据方法 必须为 Promise 对象
        loadData: parameter => {
          return getExperimentExamList(Object.assign(parameter, this.queryParam))
                  .then(res => {
                    return res.result
                  })
        },

        selectedRowKeys: [],
        selectedRows: [],
        nameType:1
      }
    },
    created () {
      getRoleList({ t: new Date()})
    },
    methods: {
      handleAdd () {
        this.visible = true
      },
      handleEdit (record) {
        this.mdl = {...record};
        console.log(this.mdl);
        this.visible = true
      },
      handleOk () {

      },

      onSelectChange (selectedRowKeys, selectedRows) {
        this.selectedRowKeys = selectedRowKeys
        this.selectedRows = selectedRows
      },
      toggleAdvanced () {
        this.advanced = !this.advanced
      },

      resetSearchForm () {
        this.queryParam = {
          date: moment(new Date())
        }
      },
      start(){
        let that = this;
        that.playing = true;
        that.lastSecond = 300;
      },
      reStart(){
        let that = this;
        that.playing = false;
        clearInterval(t);
      }
    },
    watch: {
      /*
       'selectedRows': function (selectedRows) {
       this.needTotalList = this.needTotalList.map(item => {
       return {
       ...item,
       total: selectedRows.reduce( (sum, val) => {
       return sum + val[item.dataIndex]
       }, 0)
       }
       })
       }
       */
    }
  }
</script>