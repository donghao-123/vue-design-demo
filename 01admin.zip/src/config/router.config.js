// eslint-disable-next-line
import { UserLayout, BasicLayout, RouteView, BlankLayout, PageView } from '@/components/layouts'

export const asyncRouterMap = [

  {
    path: '/',
    name: 'index',
    component: BasicLayout,
    meta: { title: '首页' },
    redirect: '/dashboard/workplace',
    children: [
      // dashboard
      {
        path: '/dashboard',
        name: 'dashboard',
        redirect: '/dashboard/workplace',
        component: RouteView,
        meta: { title: '仪表盘', keepAlive: true, icon: 'dashboard', permission: [ 'dashboard','classroom' ] },
        children: [
          {
            path: '/dashboard/analysis',
            name: 'Analysis',
            component: () => import('@/views/dashboard/Analysis'),
            meta: { title: '分析页', keepAlive: false, permission: [ 'dashboard','classroom' ] }
          },
          {
            path: '/dashboard/monitor',
            name: 'Monitor',
            hidden: true,
            component: () => import('@/views/dashboard/Monitor'),
            meta: { title: '监控页', keepAlive: true, permission: [ 'dashboard','classroom' ] }
          },
          {
            path: '/dashboard/workplace',
            name: 'Workplace',
            component: () => import('@/views/dashboard/Workplace'),
            meta: { title: '工作台', keepAlive: true, permission: [ 'dashboard','classroom' ] }
          }
        ]
      },
        // class
        {
          path: '/class',
              name: 'list',
            component: PageView,
            redirect: '/class/class-list',
            meta: { title: '班级教室', icon: 'table', permission: [ 'table','classroom' ] },
          children: [
            {
              path: '/list/class-list',
              name: 'ClassList',
              component: () => import('@/views/class/ClassList'),
              meta: { title: '班级列表', keepAlive: true, permission: [ 'table','classroom' ] }
            },
          {
            path: '/list/grade-list',
                name: 'GradeList',
              component: () => import('@/views/class/GradeList'),
              meta: { title: '年级列表', keepAlive: true, permission: [ 'table','classroom' ] }
          },
          {
            path: '/list/room-list',
                name: 'RoomList',
              component: () => import('@/views/class/RoomList'),
              meta: { title: '教室列表', keepAlive: true, permission: [ 'table','classroom' ] }
          },
        ]
        },
          // users
          {
            path: '/users',
                name: 'list',
                component: PageView,
                redirect: '/users/student-list',
                meta: { title: '人员角色', icon: 'table', permission: [ 'table','classroom' ] },
                children: [
                  {
                    path: '/users/student-list',
                    name: 'StudentList',
                    component: () => import('@/views/users/StudentList'),
                meta: { title: '学生管理', keepAlive: true, permission: [ 'table','classroom' ] }
              },
              {
                path: '/users/teacher-list',
                    name: 'TeacherList',
                    component: () => import('@/views/users/TeacherList'),
                    meta: { title: '教职工管理', keepAlive: true, permission: [ 'table','classroom' ] }
              },
              {
                path: '/users/famliy-list',
                    name: 'FamliyList',
                    component: () => import('@/views/users/FamliyList'),
                    meta: { title: '家长管理', keepAlive: true, permission: [ 'table','classroom' ] }
              },
          ]
          },
          // users
          {
            path: '/subject',
                name: 'list',
              component: PageView,
              redirect: '/users/subject-list',
              meta: { title: '学科课题', icon: 'table', permission: [ 'table','classroom' ] },
            children: [
              {
                path: '/subject/subject-list',
                name: 'SubjectList',
                component: () => import('@/views/subject/SubjectList'),
            meta: { title: '学科管理', keepAlive: true, permission: [ 'table','classroom'] }
          },
            {
              path: '/subject/schedule',
                  name: 'Schedule',
                component: () => import('@/views/subject/Schedule'),
                meta: { title: '课表管理', keepAlive: true, permission: [ 'table','classroom' ] }
            }
          ]
          },
            {
              path: '/apps',
                  name: 'apps',
                  component: RouteView,
                  meta: { title: '发现', icon: 'table', permission: [ 'table','classroom' ] },
                  children: [
                    {
                      path: '/apps/app-list',
                      name: 'appList',
                      redirect: '/apps/app-list',
                      component: PageView,
                      alwaysShow: true,
                      meta: { title: '应用管理', keepAlive: true, permission: [ 'table','classroom' ] },
                      children: [{
                        path: '/apps/app-list',
                        name: 'AppList',
                        component: () => import('@/views/apps/AppList'),
                        meta: { title: '应用管理', keepAlive: true, permission: [ 'table','classroom' ] },
                      }
                      ]
                    },
                    {
                      path: '/apps/experiment-exam-video-list',
                          name: 'ExperimentExamList',
                        component: () => import('@/views/experimentExam/Index'),
                        meta: { title: '实验考试系统', keepAlive: true, permission: [ 'table','classroom' ] },
                          alwaysShow: true,
                          children: [
                                {
                                  path: '/experiment/exam-list',
                                  name: 'ExperimentExamList',
                                  component: () => import('@/views/experimentExam/ExamList'),
                                meta: { title: '场次设置', hidden: true, keepAlive: true, permission: [ 'user','classroom' ]  }
                              },
                                {
                                  path: '/experiment/video-list',
                                      name: 'ExperimentExamVideoList',
                                    component: () => import('@/views/experimentExam/VideoList'),
                                    meta: { title: '视频管理', hidden: true, keepAlive: true, permission: [ 'user','classroom' ]  }
                                },{
                                  path: '/experiment/my-exam-list',
                                      name: 'ExperimentMyExamList',
                                      component: () => import('@/views/experimentExam/MyExamList'),
                                      meta: { title: '我的考试(学生端)', hidden: true, keepAlive: true, permission: [ 'user','classroom' ]  }
                                },
                              ]
                    },
                ]
            },
              {
                path: '/setting',
                    name: 'list',
                  component: PageView,
                  redirect: '/apps/app-list',
                  meta: { title: '设置', icon: 'table', permission: [ 'table','classroom' ] },
                children: [
                  {
                        path: '/account/settings',
                        name: 'settings',
                        component: () => import('@/views/account/settings/Index'),
                    meta: { title: '个人设置', hideHeader: true, keepAlive: true, permission: [ 'user','classroom' ]  },
                    redirect: '/account/settings/base',
                        alwaysShow: true,
                      children: [
                    {
                      path: '/account/settings/base',
                      name: 'BaseSettings',
                      component: () => import('@/views/account/settings/BaseSetting'),
                    meta: { title: '基本设置', hidden: true, keepAlive: true, permission: [ 'user','classroom' ]  }
                  },
                    {
                      path: '/account/settings/security',
                          name: 'SecuritySettings',
                        component: () => import('@/views/account/settings/Security'),
                        meta: { title: '安全设置', hidden: true, keepAlive: true, permission: [ 'user','classroom' ]  }
                    },
                    {
                      path: '/account/settings/custom',
                          name: 'CustomSettings',
                        component: () => import('@/views/account/settings/Custom'),
                        meta: { title: '个性化设置', hidden: true, keepAlive: true, permission: [ 'user','classroom' ]  }
                    },
                    {
                      path: '/account/settings/binding',
                          name: 'BindingSettings',
                        component: () => import('@/views/account/settings/Binding'),
                        meta: { title: '账户绑定', hidden: true, keepAlive: true, permission: [ 'user','classroom']  }
                    },
                  ]
                  },
                  {
                    path: '/setting/app-list',
                        name: 'AppList',
                      component: () => import('@/views/apps/AppList'),
                      meta: { title: '系统设置', keepAlive: true, permission: [ 'table','classroom' ] }
                  }
              ]
              },

      // forms

      // list

      // profile
      // result

      // Exception

      // account
    ]
  },
  {
    path: '*', redirect: '/404', hidden: true
  }
]

/**
 * 基础路由
 * @type { *[] }
 */
export const constantRouterMap = [
  {
    path: '/user',
    component: UserLayout,
    redirect: '/user/login',
    hidden: true,
    children: [
      {
        path: 'login',
        name: 'login',
        component: () => import(/* webpackChunkName: "user" */ '@/views/user/Login')
      },
      {
        path: 'register',
        name: 'register',
        component: () => import(/* webpackChunkName: "user" */ '@/views/user/Register')
      },
      {
        path: 'register-result',
        name: 'registerResult',
        component: () => import(/* webpackChunkName: "user" */ '@/views/user/RegisterResult')
      }
    ]
  },

  {
    path: '/test',
    component: BlankLayout,
    redirect: '/test/home',
    children: [
      {
        path: 'home',
        name: 'TestHome',
        component: () => import('@/views/Home')
      }
    ]
  },

  {
    path: '/404',
    component: () => import(/* webpackChunkName: "fail" */ '@/views/exception/404')
  },

]
